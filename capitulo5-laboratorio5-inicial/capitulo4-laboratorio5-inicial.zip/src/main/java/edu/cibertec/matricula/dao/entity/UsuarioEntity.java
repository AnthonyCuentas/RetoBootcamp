package edu.cibertec.matricula.dao.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.util.Arrays;

@Entity
@Table(name = "usuario")
public class UsuarioEntity {
  @Id
  private String usuario;

  private String clave;

  @Column(name = "nomcompleto")
  private String nombreCompleto;

  private byte[] foto;

  public UsuarioEntity() {
  }

  public UsuarioEntity(String usuario, String clave, String nombreCompleto, byte[] foto) {
    this.usuario = usuario;
    this.clave = clave;
    this.nombreCompleto = nombreCompleto;
    this.foto = foto;
  }

  public String getUsuario() {
    return usuario;
  }

  public void setUsuario(String usuario) {
    this.usuario = usuario;
  }

  public String getClave() {
    return clave;
  }

  public void setClave(String clave) {
    this.clave = clave;
  }

  public String getNombreCompleto() {
    return nombreCompleto;
  }

  public void setNombreCompleto(String nombreCompleto) {
    this.nombreCompleto = nombreCompleto;
  }

  public byte[] getFoto() {
    return foto;
  }

  public void setFoto(byte[] foto) {
    this.foto = foto;
  }

  @Override
  public String toString() {
    return "UsuarioEntity{" +
      "usuario='" + usuario + '\'' +
      ", clave='" + clave + '\'' +
      ", nombreCompleto='" + nombreCompleto + '\'' +
      ", foto=" + Arrays.toString(foto) +
      '}';
  }
}
